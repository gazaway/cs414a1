package cs414.a1.gazawayj;


public enum ProjectSize {
	small, medium, large;
}