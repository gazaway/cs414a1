package cs414.a1.gazawayj;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

@RunWith(Suite.class)
@SuiteClasses({ CompanyTest.class, ProjectTest.class, QualificationTest.class,
		WorkerTest.class })
public class TestAll {
	
}
