package cs414.a1.gazawayj;


public enum ProjectStatus {
	planned, active, finished, suspended;
}